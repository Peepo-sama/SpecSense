#include "SpecSense.h"
#include "./ui_SpecSense.h"
#include <iostream>
#include <qthread.h>
using namespace std;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_pushButton_clicked()
{

    for(int value; value<=100; value++){

        ui->progressBar->setValue(value);

    }
}




void MainWindow::on_progressBar_valueChanged(int value)
{

}

